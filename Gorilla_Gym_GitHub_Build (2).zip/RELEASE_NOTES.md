# دليل الرفع والنشر النهائي لتطبيق Gorilla Gym

تم تحديث وتعديل المشروع بالكامل ليكون جاهزاً للإنتاج والرفع على المتاجر وتنسيق الاستضافة.

---

## 1. التعديلات والتسينات التي تم تطبيقها:

### 📱 تطبيق الأندرويد (Android App):
1. **تفعيل Protection & Shrinking**:
   - تم تفعيل `minifyEnabled true` و `shrinkResources true` لتقليل حجم التطبيق وحماية الكود من الهندسة العكسية.
2. **حماية قواعد البيانات والأمان**:
   - تعطيل النسخ الاحتياطي غير الآمن (`allowBackup="false"`).
   - تعطيل الاتصالات غير المشفرة (`usesCleartextTraffic="false"`) لإجبار استخدام HTTPS للاتصال بالسيرفر.
3. **تطبيق قواعد ProGuard**:
   - إضافة قواعد لحماية مكونات الـ WebView والـ JavaScript Interfaces.
4. **تحسين أداء الواجهة**:
   - إضافة `configChanges` لمنع إعادة تحميل الـ WebView عند تغير حالة الشاشة.

### 🌐 الخادم والـ Backend:
1. **بيئة الإنتاج (Production Environment)**:
   - إضافة وإعداد ملف `.env` و `.env.example` بإعدادات الأمان.
   - إعداد المتغيرات الهامة مثل `NODE_ENV=production` و `JWT_SECRET`.

---

## 2. خطوات رفع وتجميع التطبيق للرفع (Building Production Release):

### أ) لتجميع ملف APK / AAB للتطبيقات (Google Play):
1. قم بإنشاء مفتاح التوقيع (Keystore) لربط التطبيق:
   ```bash
   keytool -genkey -v -keystore gorilla-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias gorilla-alias
   ```
2. قم بتعديل رابط السيرفر النهائي بداخل:
   `android-app/app/src/main/res/values/strings.xml`
3. قم بتوليد ملف Bundle الإنتاجي (.aab):
   ```bash
   cd android-app
   ./gradlew bundleRelease
   ```
   سيتم إنشاء الملف المنسق الجاهز للرفع على **Google Play Console** في المسار:
   `android-app/app/build/outputs/bundle/release/app-release.aab`

---

### ب) تشغيل الخادم (Backend Deployment):
1. انقل مجلد `backend` إلى السيرفر الخاص بك (مثل Render, VPS, AWS, Railway).
2. قم بتثبيت التبعيات:
   ```bash
   npm install --production
   ```
3. قم بتغيير كلمة المرور للآدمن ومفتاح الـ JWT في ملف `.env`.
4. قم بتشغيل الخادم عبر PM2 أو Docker:
   ```bash
   npm start
   ```

تهانينا! التطبيق الآن مجهز بأعلى معايير الأمان والأداء للرفع المباشر.
