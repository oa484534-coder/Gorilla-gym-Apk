@echo off
setlocal
cd /d "%~dp0android-app"

echo ========================================
echo        Gorilla Gym - APK Builder
echo ========================================
echo.

if not exist "gradlew.bat" (
  echo [1/3] Gradle wrapper not found. Trying installed Gradle...
  where gradle >nul 2>&1
  if errorlevel 1 (
    echo.
    echo ERROR: Gradle is not installed.
    echo Install Android Studio/Android SDK + Gradle, then run this file again.
    echo The project is already configured for the Gorilla Gym Netlify URL.
    pause
    exit /b 1
  )
  set GRADLE_CMD=gradle
) else (
  set GRADLE_CMD=gradlew.bat
)

echo [2/3] Building release APK...
call %GRADLE_CMD% assembleRelease
if errorlevel 1 (
  echo.
  echo BUILD FAILED.
  pause
  exit /b 1
)

echo [3/3] Copying APK...
if not exist "..\APK" mkdir "..\APK"
copy /Y "app\build\outputs\apk\release\app-release.apk" "..\APK\GorillaGym.apk" >nul

echo.
echo ========================================
echo BUILD COMPLETE!
echo APK: APK\GorillaGym.apk
echo ========================================
pause
