#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/android-app"

if [[ -x ./gradlew ]]; then
  GRADLE=./gradlew
elif command -v gradle >/dev/null 2>&1; then
  GRADLE=gradle
else
  echo "Gradle is not installed and no Gradle wrapper is present."
  echo "Install Android Studio/SDK + Gradle, then run this script again."
  exit 1
fi

$GRADLE assembleRelease
mkdir -p ../APK
cp -f app/build/outputs/apk/release/app-release.apk ../APK/GorillaGym.apk
echo "APK created: APK/GorillaGym.apk"
