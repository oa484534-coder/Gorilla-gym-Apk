require("dotenv").config();
const express = require("express");
const path = require("path");
const crypto = require("crypto");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const cookieParser = require("cookie-parser");
const rateLimit = require("express-rate-limit");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, "");
const db = new Database(path.join(__dirname, "data", "gorilla.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  plan TEXT NOT NULL,
  price INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  paymob_order_id TEXT,
  paymob_intention_id TEXT,
  transaction_id TEXT,
  payment_method TEXT NOT NULL DEFAULT 'instapay',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paid_at TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER,
  kind TEXT NOT NULL DEFAULT 'admin',
  expires_at INTEGER NOT NULL
);
`);
try { db.exec("ALTER TABLE bookings ADD COLUMN user_id INTEGER"); } catch(e) {}

const PLANS = {
  month: {name:"شهري", months:1, price:400},
  "2months": {name:"شهرين", months:2, price:900},
  "3months": {name:"3 شهور", months:3, price:1000},
  year: {name:"سنوي", months:12, price:1800}
};

app.use(express.json({limit:"100kb"}));
app.use(express.urlencoded({extended:false}));
app.use(cookieParser());

const loginLimiter = rateLimit({windowMs:15*60*1000, max:20, standardHeaders:true, legacyHeaders:false});
const bookingLimiter = rateLimit({windowMs:10*60*1000, max:50, standardHeaders:true, legacyHeaders:false});
const registerLimiter = rateLimit({windowMs:15*60*1000, max:10, standardHeaders:true, legacyHeaders:false});

function clean(s,max=200){ return String(s ?? "").trim().slice(0,max); }
function validEmail(e){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }
function hashToken(t){ return crypto.createHash("sha256").update(t).digest("hex"); }
function newSession(userId, kind){
  const token=crypto.randomBytes(32).toString("hex");
  db.prepare("INSERT INTO sessions(token_hash,user_id,kind,expires_at) VALUES(?,?,?,?)")
    .run(hashToken(token), userId || null, kind, Date.now()+7*24*60*60*1000);
  return token;
}
function getSession(req, kind){
  const token=req.cookies[kind==="admin" ? "gorilla_admin" : "gorilla_user"];
  if(!token) return null;
  const row=db.prepare("SELECT * FROM sessions WHERE token_hash=? AND kind=?").get(hashToken(token),kind);
  if(!row || row.expires_at < Date.now()){
    if(row) db.prepare("DELETE FROM sessions WHERE token_hash=?").run(row.token_hash);
    return null;
  }
  return row;
}
function adminAuth(req,res,next){
  const s=getSession(req,"admin");
  if(!s) return res.status(401).json({error:"غير مصرح"});
  req.adminSession=s; next();
}
function userAuth(req,res,next){
  const s=getSession(req,"user");
  if(!s) return res.status(401).json({error:"يجب تسجيل الدخول أولاً"});
  req.userSession=s;
  req.user=db.prepare("SELECT id,name,phone,email,created_at FROM users WHERE id=?").get(s.user_id);
  if(!req.user) return res.status(401).json({error:"الحساب غير موجود"});
  next();
}

function paymobConfigured(){
  return !!(process.env.PAYMOB_SECRET_KEY && process.env.PAYMOB_PUBLIC_KEY && process.env.PAYMOB_INTEGRATION_IDS);
}
async function createPaymobIntention(booking){
  if(!paymobConfigured()) return null;
  const [firstName,...rest]=booking.name.split(/\s+/);
  const lastName=rest.join(" ")||firstName;
  const integrationIds=process.env.PAYMOB_INTEGRATION_IDS.split(",").map(x=>Number(x.trim())).filter(Boolean);
  const body={
    amount:booking.price*100,currency:"EGP",payment_methods:integrationIds,
    items:[{name:`Gorilla Gym - ${PLANS[booking.plan].name}`,amount:booking.price*100,description:"Gorilla Gym membership",quantity:1}],
    billing_data:{apartment:"dumy",street:"dumy",building:"dumy",floor:"dumy",city:"Cairo",state:"Cairo",country:"EGY",first_name:firstName,last_name:lastName,phone_number:booking.phone,email:booking.email},
    special_reference:`GORILLA-${booking.id}`,expiration:86400,
    notification_url:`${BASE_URL}/api/paymob/webhook`,redirection_url:`${BASE_URL}/payment-result`
  };
  const r=await fetch("https://accept.paymob.com/v1/intention/",{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Token ${process.env.PAYMOB_SECRET_KEY}`},body:JSON.stringify(body)});
  const data=await r.json();
  if(!r.ok) throw new Error(data?.message||data?.detail||"Paymob intention failed");
  db.prepare("UPDATE bookings SET paymob_order_id=?,paymob_intention_id=? WHERE id=?")
    .run(String(data.intention_order_id||""),String(data.id||""),booking.id);
  return {url:`https://accept.paymob.com/unifiedcheckout/?publicKey=${encodeURIComponent(process.env.PAYMOB_PUBLIC_KEY)}&clientSecret=${encodeURIComponent(data.client_secret)}`};
}
function verifyPaymobHmac(obj,received){
  if(!process.env.PAYMOB_HMAC_SECRET||!received) return false;
  const values=[obj.amount_cents,obj.created_at,obj.currency,obj.error_occured,obj.has_parent_transaction,obj.id,obj.integration_id,obj.is_3d_secure,obj.is_auth,obj.is_capture,obj.is_refunded,obj.is_standalone_payment,obj.is_voided,obj.order?.id,obj.owner,obj.pending,obj.source_data?.pan,obj.source_data?.sub_type,obj.source_data?.type,obj.success]
    .map(v=>v===undefined||v===null?"":String(v)).join("");
  const calculated=crypto.createHmac("sha512",process.env.PAYMOB_HMAC_SECRET).update(values).digest("hex");
  return crypto.timingSafeEqual(Buffer.from(calculated),Buffer.from(String(received)));
}

/* Public/auth pages */
app.use(express.static(path.join(__dirname,"public"),{index:"index.html"}));
app.get("/admin.html",adminAuth,(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
app.get("/admin-login",(req,res)=>res.sendFile(path.join(__dirname,"public","admin-login.html")));
app.get("/account",(req,res)=>res.sendFile(path.join(__dirname,"public","account.html")));
app.get("/login",(req,res)=>res.sendFile(path.join(__dirname,"public","login.html")));

/* User auth */
app.post("/api/auth/register",registerLimiter,async(req,res)=>{
  try{
    const name=clean(req.body.name,100), phone=clean(req.body.phone,30), email=clean(req.body.email,120).toLowerCase(), password=String(req.body.password||"");
    if(!name||!phone||!validEmail(email)||password.length<6) return res.status(400).json({error:"أدخل البيانات بشكل صحيح، وكلمة المرور 6 أحرف على الأقل."});
    if(db.prepare("SELECT id FROM users WHERE email=?").get(email)) return res.status(409).json({error:"البريد الإلكتروني مسجل بالفعل."});
    const hash=await bcrypt.hash(password,12);
    const result=db.prepare("INSERT INTO users(name,phone,email,password_hash) VALUES(?,?,?,?)").run(name,phone,email,hash);
    const token=newSession(result.lastInsertRowid,"user");
    res.cookie("gorilla_user",token,{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",maxAge:7*24*60*60*1000});
    res.json({ok:true});
  }catch(e){ console.error(e); res.status(500).json({error:"تعذر إنشاء الحساب."}); }
});
app.post("/api/auth/login",loginLimiter,async(req,res)=>{
  const email=clean(req.body.email,120).toLowerCase(), password=String(req.body.password||"");
  const user=db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if(!user || !(await bcrypt.compare(password,user.password_hash))) return res.status(401).json({error:"البريد أو كلمة المرور غير صحيحة."});
  const token=newSession(user.id,"user");
  res.cookie("gorilla_user",token,{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",maxAge:7*24*60*60*1000});
  res.json({ok:true});
});
app.post("/api/auth/logout",userAuth,(req,res)=>{
  const token=req.cookies.gorilla_user; db.prepare("DELETE FROM sessions WHERE token_hash=?").run(hashToken(token)); res.clearCookie("gorilla_user"); res.json({ok:true});
});
app.get("/api/auth/me",userAuth,(req,res)=>res.json({ok:true,user:req.user}));
app.get("/api/my/bookings",userAuth,(req,res)=>{
  res.json(db.prepare("SELECT id,plan,price,status,payment_method,created_at,paid_at FROM bookings WHERE user_id=? ORDER BY id DESC").all(req.user.id));
});

/* Plans + bookings */
app.get("/api/plans",(req,res)=>res.json(PLANS));
app.post("/api/bookings",bookingLimiter,userAuth,async(req,res)=>{
  try{
    const plan=clean(req.body.plan,20), paymentMethod=clean(req.body.paymentMethod,20);
    if(!PLANS[plan]||!["instapay","paymob"].includes(paymentMethod)) return res.status(400).json({error:"راجع الباقة وطريقة الدفع."});
    const p=PLANS[plan], u=req.user;
    const result=db.prepare("INSERT INTO bookings(user_id,name,phone,email,plan,price,status,payment_method) VALUES(?,?,?,?,?,?,?,?)")
      .run(u.id,u.name,u.phone,u.email,plan,p.price,"pending",paymentMethod);
    const booking=db.prepare("SELECT * FROM bookings WHERE id=?").get(result.lastInsertRowid);
    let payment=null;
    if(paymentMethod==="paymob"&&paymobConfigured()) payment=await createPaymobIntention(booking);
    res.json({ok:true,bookingId:booking.id,paymentUrl:payment?.url||null,paymentEnabled:!!payment,paymentMethod});
  }catch(e){console.error(e);res.status(500).json({error:"حصل خطأ أثناء إنشاء الحجز."});}
});

/* Admin */
app.post("/api/admin/login",loginLimiter,async(req,res)=>{
  const username=clean(req.body.username,100), password=String(req.body.password||"");
  const expectedUser=process.env.ADMIN_USERNAME||"admin", expectedPass=process.env.ADMIN_PASSWORD||"CHANGE_ME";
  if(username!==expectedUser||password!==expectedPass) return res.status(401).json({error:"بيانات الدخول غير صحيحة"});
  const token=newSession(null,"admin");
  res.cookie("gorilla_admin",token,{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",maxAge:7*24*60*60*1000});
  res.json({ok:true});
});
app.post("/api/admin/logout",adminAuth,(req,res)=>{
  const token=req.cookies.gorilla_admin; db.prepare("DELETE FROM sessions WHERE token_hash=?").run(hashToken(token)); res.clearCookie("gorilla_admin"); res.json({ok:true});
});
app.get("/api/admin/me",adminAuth,(req,res)=>res.json({ok:true}));
app.get("/api/admin/bookings",adminAuth,(req,res)=>res.json(db.prepare("SELECT * FROM bookings ORDER BY id DESC").all()));
app.patch("/api/admin/bookings/:id/status",adminAuth,(req,res)=>{
  const status=clean(req.body.status,20);
  if(!["pending","paid","failed","cancelled"].includes(status)) return res.status(400).json({error:"حالة غير صحيحة"});
  db.prepare("UPDATE bookings SET status=?,paid_at=CASE WHEN ?='paid' THEN CURRENT_TIMESTAMP ELSE paid_at END WHERE id=?").run(status,status,Number(req.params.id));
  res.json({ok:true});
});

/* Paymob */
app.post("/api/paymob/webhook",(req,res)=>{
  try{
    const obj=req.body?.obj, received=req.query.hmac||req.body?.hmac;
    if(!obj) return res.status(400).send("bad payload");
    if(process.env.PAYMOB_HMAC_SECRET&&!verifyPaymobHmac(obj,received)) return res.status(401).send("invalid hmac");
    const reference=String(obj.order?.merchant_order_id||obj.merchant_order_id||"");
    const match=reference.match(/^GORILLA-(\d+)$/), bookingId=match?Number(match[1]):null;
    if(bookingId){
      let status="pending";
      if(obj.success===true&&obj.pending===false&&!obj.error_occured&&!obj.is_refunded&&!obj.is_voided) status="paid";
      else if(obj.success===false||obj.error_occured===true) status="failed";
      db.prepare("UPDATE bookings SET status=?,transaction_id=?,paid_at=CASE WHEN ?='paid' THEN CURRENT_TIMESTAMP ELSE paid_at END WHERE id=?").run(status,String(obj.id||""),status,bookingId);
    }
    res.send("ok");
  }catch(e){console.error(e);res.status(500).send("error");}
});

app.get("/payment",(req,res)=>res.sendFile(path.join(__dirname,"public","payment.html")));
app.get("/payment-result",(req,res)=>res.sendFile(path.join(__dirname,"public","payment-result.html")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Gorilla Gym running on ${BASE_URL}`));
